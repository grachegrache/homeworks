/*
 * mycat.h
 *
 *  Created on: 2015. 11. 7.
 *      Author: panda
 */

#ifndef ABOUT_FILE_H_
#define ABOUT_FILE_H_

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

extern int parse_arg(char*, char**);
extern void print_man(const char*);

#endif /* ABOUT_FILE_H_ */
